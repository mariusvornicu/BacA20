
# Scholarly HTML Community Group repository

[![Join the chat at https://gitter.im/w3c/scholarly-html](https://badges.gitter.im/Join%20Chat.svg)](https://gitter.im/w3c/scholarly-html?utm_source=badge&utm_medium=badge&utm_campaign=pr-badge&utm_content=badge)

This is the repository of the
[Scholarly HTML Community Group](https://www.w3.org/community/scholarlyhtml/).

Additional links:

* [Contact This Group](mailto:public-scholarlyhtml@w3.org)
* [Mailing list archive](https://lists.w3.org/Archives/Public/public-scholarlyhtml/)
* [Join the group](https://www.w3.org/community/scholarlyhtml/join)

A browser friendly reading of the specifications in this repository is possible through
[github.io](https://w3c.github.io/scholarly-html/).

If you are member of that Community Group and you want to be added as a possible direct contributor
to this repository, please contact Robin Berjon (robin@berjon.com) or Ivan Herman (ivan@w3.org),
providing them with your github handle.
